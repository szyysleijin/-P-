<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
body{
	padding:0;margin:0;
}
div{box-sizing: border-box;}
a{text-decoration:none; out-line: none; color:#333}
div:after{
	content:'';
	display: block;
	clear: both;
}
</style>
