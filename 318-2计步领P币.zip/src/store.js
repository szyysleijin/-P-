import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
		isRecord:false,	//记录用户是否打卡
  },
  mutations: {

  },
  actions: {

  }
})
